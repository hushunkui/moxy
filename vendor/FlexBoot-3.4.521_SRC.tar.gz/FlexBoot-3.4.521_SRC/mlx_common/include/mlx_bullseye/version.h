/* $Id: version.h.in 14513 2014-02-27 23:05:56Z Steve Cornett $
 * Copyright (c) Bullseye Testing Technology
 */

#define VERSION_normal "8.9.41"
#define VERSION_number "809041"
#define VERSION_title "BullseyeCoverage 8.9.41"
#define VERSION_copyright "Copyright (c) Bullseye Testing Technology 1990-2014"
